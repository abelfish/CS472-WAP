/**
 * 
 * student.js
 *  */
"use strict";

export default class Student {
  constructor(studentId, studentName, levelOfStudy) {
    this.studentId = studentId;
    this.studentName = studentName;
    this.levelOfStudy = levelOfStudy;
  }
}
